﻿namespace YourWallet
{


    partial class databaseSet
    {
    }
}

namespace YourWallet.databaseSetTableAdapters
{


    public partial class tablicaTableAdapter
    {
    }
}
